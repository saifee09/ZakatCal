document.getElementById('calculate-btn').addEventListener('click', function () {
    // Get input values
    const cash = parseFloat(document.getElementById('cash').value) || 0;
    const gold = parseFloat(document.getElementById('gold').value) || 0;
    const silver = parseFloat(document.getElementById('silver').value) || 0;
    const assets = parseFloat(document.getElementById('assets').value) || 0;

    // Define Nisab threshold (example: value of 87.48 grams of gold in the user's currency)
    const nisab = 80000; // Replace with current gold/silver value in your currency

    // Calculate total assets
    const totalAssets = cash + gold + silver + assets;

    // Check if assets exceed the Nisab
    const isEligible = totalAssets >= nisab;

    // Calculate Zakat (2.5% of total assets)
    const zakatAmount = isEligible ? (totalAssets * 0.025).toFixed(2) : 0;

    // Update the result section
    const resultSection = document.getElementById('result');
    const zakatMessage = document.getElementById('zakat-message');
    const zakatAmountDisplay = document.getElementById('zakat-amount');

    if (isEligible) {
        zakatMessage.textContent = `Your total assets are ${totalAssets.toFixed(2)}. You are eligible to pay Zakat.`;
        zakatAmountDisplay.textContent = `Zakat Amount: ${zakatAmount}`;
    } else {
        zakatMessage.textContent = `Your total assets are ${totalAssets.toFixed(2)}. You are not eligible to pay Zakat.`;
        zakatAmountDisplay.textContent = '';
    }

    // Show the result section
    resultSection.style.display = 'block';
});
